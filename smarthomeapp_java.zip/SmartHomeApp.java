import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicSliderUI;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

// using of abstraction in base class "Device"
abstract class Device {
    private String name;          // Encapsulation: Private field, accessible only through getter method
    private boolean isOn;         // Encapsulation: Private field, accessible only through getter and control methods

    public Device(String name) {  // constructor of the base class
        this.name = name;
        this.isOn = false;
    }

    public String getName() {     // Encapsulation: Public method to access private field "name"
        return name;
    }

    public boolean isOn() {       // Encapsulation: Public method to access private field "isOn"
        return isOn;
    }

    public void turnOn() {        // Encapsulation: Public method to modify private field "isOn"
        isOn = true;
    }

    public void turnOff() {       // Encapsulation: Public method to modify private field "isOn"
        isOn = false;
    }

    public abstract String control(); // abstract method
}

// using of inheritance to extend Light from parent class Device
class Light extends Device {
    private int brightness;       // Encapsulation: Private field, accessible only through getter and setter methods

    public Light(String name, int brightness) {  // constructor to initialize the properties of class Light
        super(name);                             // super keyword is used to access the members (methods or field) of the parent class
        this.brightness = brightness;            // this keyword is used to initialize the current object or properties in a constructor 
    }

    public int getBrightness() {  // Encapsulation: Public method to access private field "brightness"
        return brightness;
    }

    // used exception to make sure brightness stays within the limit (invalidsettingexception)
    public void setBrightness(int brightness) throws InvalidSettingException {  // Encapsulation: Setter method to validate and modify "brightness"
        if (brightness < 0 || brightness > 100) {
            throw new InvalidSettingException("Brightness must be between 0 and 100");
        }
        this.brightness = brightness;
    }
    
    // using runtime polymorphism to override the abstract function control of the base class Device
    @Override
    public String control() {
        return getName() + " is " + (isOn() ? "On" : "Off") + " at brightness " + brightness + "%";
    }
}

// using inheritance to extend Fan from parent class Device
class Fan extends Device {
    private int speed;            // Encapsulation: Private field, accessible only through getter and setter methods

    public Fan(String name, int speed) {  // constructor for class Fan
        super(name);                      // super keyword is used to access the members (methods or field) of the parent class
        this.speed = speed;               // this keyword is used to initialize the current object or properties in a constructor
    }

    public int getSpeed() {          // Encapsulation: Public method to access private field "speed"
        return speed;
    }
    
    // used exception to make sure speed stays within the limit (invalidsettingexception)
    public void setSpeed(int speed) throws InvalidSettingException {  // Encapsulation: Setter method to validate and modify "speed"
        if (speed < 1 || speed > 5) {
            throw new InvalidSettingException("Fan speed must be between 1 and 5");
        }
        this.speed = speed;
    }

    // using runtime polymorphism to override the abstract function control of the base class Device
    @Override
    public String control() {
        return getName() + " is " + (isOn() ? "On" : "Off") + " at speed level " + speed;
    }
}

// using inheritance to extend AC from parent class Device
class AC extends Device {
    private int temperature;       // Encapsulation: Private field, accessible only through getter and setter methods

    public AC(String name, int temperature) {  // constructor for class AC
        super(name);                           // super keyword is used to access the members (methods or field) of the parent class
        this.temperature = temperature;        // this keyword is used to initialize the current object or properties in a constructor
    }

    public int getTemperature() {  // Encapsulation: Public method to access private field "temperature"
        return temperature;
    }

    // used exception to make sure temperature stays within the limit (invalidsettingexception)
    public void setTemperature(int temperature) throws InvalidSettingException {  // Encapsulation: Setter method to validate and modify "temperature"
        if (temperature < 16 || temperature > 30) {
            throw new InvalidSettingException("AC temperature must be between 16°C and 30°C");
        }
        this.temperature = temperature;
    }

    // using runtime polymorphism to override the abstract function control of the base class Device
    @Override
    public String control() {
        return getName() + " is " + (isOn() ? "On" : "Off") + " at " + temperature + "°C";
    }
}

// using inheritance to extend Refrigerator from parent class Device
class Refrigerator extends Device {
    private int temperature;       // Encapsulation: Private field, accessible only through getter and setter methods

    public Refrigerator(String name, int temperature) {  // constructor for class Refrigerator
        super(name);                                     // super keyword is used to access the members (methods or field) of the parent class
        this.temperature = temperature;                  // this keyword is used to initialize the current object or properties in a constructor
    }

    public int getTemperature() {    // Encapsulation: Public method to access private field "temperature"
        return temperature;
    }
      
    // used exception to make sure temperature stays within the limit (invalidsettingexception)
    public void setTemperature(int temperature) throws InvalidSettingException {  // Encapsulation: Setter method to validate and modify "temperature"
        if (temperature < 1 || temperature > 10) {
            throw new InvalidSettingException("Refrigerator temperature must be between 1°C and 10°C");
        }
        this.temperature = temperature;
    }
    
    // using runtime polymorphism to override the abstract function control of the base class Device
    @Override
    public String control() {
        return getName() + " is " + (isOn() ? "On" : "Off") + " at " + temperature + "°C";
    }
}

// Exception class for invalid settings
class InvalidSettingException extends Exception {
    public InvalidSettingException(String message) {
        super(message);
    }
}

// SmartHome GUI Application
public class SmartHomeApp {
    private JFrame frame;
    private ArrayList<Device> devices;

    public SmartHomeApp() {
        devices = new ArrayList<>();
        devices.add(new Light("Living Room Light", 70));
        devices.add(new Fan("Bedroom Fan", 3));
        devices.add(new AC("Living Room AC", 24));
        devices.add(new Refrigerator("Kitchen Refrigerator", 4));

        initialize();
    }

    private void initialize() {
        frame = new JFrame("Smart Home Automation System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 500);
        frame.getContentPane().setBackground(new Color(30, 30, 30));
        frame.setLayout(new GridLayout(0, 1, 10, 10));

        for (Device device : devices) {
            JPanel panel = new JPanel();
            panel.setLayout(new FlowLayout());
            panel.setBackground(new Color(45, 45, 48));
            panel.setBorder(new EmptyBorder(10, 10, 10, 10));

            JLabel label = new JLabel(device.control());
            label.setFont(new Font("Verdana", Font.PLAIN, 14));
            label.setForeground(Color.LIGHT_GRAY);

            JButton toggleButton = new JButton(device.isOn() ? "Turn Off" : "Turn On");
            styleButton(toggleButton);

            toggleButton.addActionListener(e -> {
                if (device.isOn()) {
                    device.turnOff();
                } else {
                    device.turnOn();
                }
                label.setText(device.control());
                toggleButton.setText(device.isOn() ? "Turn Off" : "Turn On");
            });

            panel.add(label);
            panel.add(toggleButton);

            if (device instanceof Light) {
                JSlider brightnessSlider = createStyledSlider(0, 100, ((Light) device).getBrightness());
                brightnessSlider.addChangeListener(e -> {
                    try {
                        ((Light) device).setBrightness(brightnessSlider.getValue());
                        label.setText(device.control());
                    } catch (InvalidSettingException ex) {
                        showError(ex.getMessage());
                    }
                });
                panel.add(new JLabel("Brightness:", JLabel.CENTER)).setForeground(Color.WHITE);
                panel.add(brightnessSlider);
            } else if (device instanceof Fan) {
                JSlider speedSlider = createStyledSlider(1, 5, ((Fan) device).getSpeed());
                speedSlider.addChangeListener(e -> {
                    try {
                        ((Fan) device).setSpeed(speedSlider.getValue());
                        label.setText(device.control());
                    } catch (InvalidSettingException ex) {
                        showError(ex.getMessage());
                    }
                });
                panel.add(new JLabel("Speed:", JLabel.CENTER)).setForeground(Color.WHITE);
                panel.add(speedSlider);
            } else if (device instanceof AC) {
                JSlider tempSlider = createStyledSlider(16, 30, ((AC) device).getTemperature());
                tempSlider.addChangeListener(e -> {
                    try {
                        ((AC) device).setTemperature(tempSlider.getValue());
                        label.setText(device.control());
                    } catch (InvalidSettingException ex) {
                        showError(ex.getMessage());
                    }
                });
                panel.add(new JLabel("Temperature:", JLabel.CENTER)).setForeground(Color.WHITE);
                panel.add(tempSlider);
            } else if (device instanceof Refrigerator) {
                JSlider fridgeTempSlider = createStyledSlider(1, 10, ((Refrigerator) device).getTemperature());
                fridgeTempSlider.addChangeListener(e -> {
                    try {
                        ((Refrigerator) device).setTemperature(fridgeTempSlider.getValue());
                        label.setText(device.control());
                    } catch (InvalidSettingException ex) {
                        showError(ex.getMessage());
                    }
                });
                panel.add(new JLabel("Fridge Temp:", JLabel.CENTER)).setForeground(Color.WHITE);
                panel.add(fridgeTempSlider);
            }

            frame.add(panel);
        }

        frame.setVisible(true);
    }

    // Helper methods for UI styling
    private void styleButton(JButton button) {
        button.setFocusPainted(false);
        button.setBackground(new Color(85, 172, 238));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Verdana", Font.BOLD, 12));
        button.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    private JSlider createStyledSlider(int min, int max, int value) {
        JSlider slider = new JSlider(min, max, value);
        slider.setUI(new BasicSliderUI(slider) {
            protected Color getTrackColor() {
                return new Color(85, 172, 238);
            }
        });
        slider.setBackground(new Color(45, 45, 48));
        slider.setForeground(Color.LIGHT_GRAY);
        return slider;
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(frame, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(SmartHomeApp::new);
    }
}
